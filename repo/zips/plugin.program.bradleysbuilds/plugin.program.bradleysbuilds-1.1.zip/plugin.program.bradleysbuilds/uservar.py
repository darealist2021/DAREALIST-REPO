import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://the666mafia.com/txt/maintance.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
