'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/darealist2021/DAREALIST-BUILDS/refs/heads/main/darealistbuildsnew.xml'

'''#####-----Videos File-----#####'''
videos_url = 'replace me'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/darealist2021/DAREALIST-BUILDS/refs/heads/main/darealistnotify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
